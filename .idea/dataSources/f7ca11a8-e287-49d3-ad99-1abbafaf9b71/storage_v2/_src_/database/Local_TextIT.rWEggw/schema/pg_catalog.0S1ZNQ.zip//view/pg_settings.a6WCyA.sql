create view pg_settings
            (name, setting, unit, category, short_desc, extra_desc, context, vartype, source, min_val, max_val,
             enumvals, boot_val, reset_val, sourcefile, sourceline, pending_restart)
as
SELECT name,
       setting,
       unit,
       category,
       short_desc,
       extra_desc,
       context,
       vartype,
       source,
       min_val,
       max_val,
       enumvals,
       boot_val,
       reset_val,
       sourcefile,
       sourceline,
       pending_restart
FROM pg_show_all_settings() a(name, setting, unit, category, short_desc, extra_desc, context, vartype, source, min_val,
                              max_val, enumvals, boot_val, reset_val, sourcefile, sourceline, pending_restart);

alter table pg_settings
    owner to postgres;

grant select, update on pg_settings to public;

